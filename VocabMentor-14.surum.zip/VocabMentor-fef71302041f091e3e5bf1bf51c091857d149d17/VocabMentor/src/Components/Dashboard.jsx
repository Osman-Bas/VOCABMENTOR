import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

import { fetchUserName } from "../firebase";
import { auth } from "../firebase";
import loadingGif from "../assets/Spin@1x-1.0s-200px-200px (1).gif";

const Dashboard = () => {
  const [userName, setUserName] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const uid = localStorage.getItem("uid");
        if (uid) {
          const name = await fetchUserName(uid);
          setUserName(name);
          setLoading(false);
        } else {
          navigate("/login");
        }
      } catch (error) {
        console.error("Kullanıcı adı alınırken hata oluştu:", error);
        navigate("/login");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <div className="container-fluid">
        <Link to={"/"} className="text-decoration-none">
          <h1
            id="AppName"
            className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third "
          >
            VocabMentor
          </h1>
        </Link>
        <div className="row  bg-secondary row-cols-1 row-cols-md-2 d-flex align-items-center justify-content-center mt-4 position-relative">
          {loading ? (
            <div className="loading d-flex align-items-center justify-content-center">
              <img
                className="loading-gif"
                src={loadingGif}
                alt="Yükleniyor..."
              />
            </div>
          ) : (
            <>
              <div
                className="col-md-5 col-10 dashboard-col-left p-5 .poetsen-one-regular  rounded"
                id="welcome"
              >
                <span className="fs-1">
                  Hoşgeldin {userName}, günün nasıl geçiyor?
                </span>
                <iframe
                  className=""
                  src="https://lottie.host/embed/6efbabba-0c73-4a03-8252-40528f38fa7f/Y8dh7mqAI5.json"
                ></iframe>
              </div>
              <div className="col-md-5 col-10 dashboard-menu d-flex flex-column align-items-center justify-content-evenly rounded p-4 ">
                <Link
                  to="/quiz"
                  className="text-decoration-none dashboard-menu-link   primary text-center"
                >
                  Sınava başla
                </Link>{" "}
                <Link
                  to="/wordaddpage"
                  className="text-decoration-none dashboard-menu-link  primary text-center"
                >
                  Kelime ekle
                </Link>{" "}
                <Link
                  to="/analysis"
                  className="text-decoration-none dashboard-menu-link  primary text-center"
                >
                  Analiz Raporu
                </Link>{" "}
                <Link
                  to="/settings"
                  className="text-decoration-none  dashboard-menu-link primary text-center"
                >
                  Ayarlar
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};
export default Dashboard;
