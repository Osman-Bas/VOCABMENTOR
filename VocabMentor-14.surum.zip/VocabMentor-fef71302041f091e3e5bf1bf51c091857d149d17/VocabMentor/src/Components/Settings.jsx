import React, { useState, useEffect } from "react";
import { changeWordCount, getQuestionCount, logout } from "../firebase";
import { Link, useNavigate } from "react-router-dom";
import { Toaster, toast } from "react-hot-toast";
const Settings = () => {
  const [wordCount, setWordCount] = useState("..");
  const navigate = useNavigate();
  const uid = localStorage.getItem("uid");

  useEffect(() => {
    const fetchWordCount = async () => {
      try {
        const count = await getQuestionCount(uid);
        console.log(count.wordCount);
        setWordCount(count.wordCount);
      } catch (error) {
        console.log("hata", error);
        navigate("/login");
      }
    };

    fetchWordCount();
  }, []);
  const increaseWordCount = () => {
    setWordCount(wordCount + 1);
  };

  const decreaseWordCount = () => {
    if (wordCount > 1) {
      setWordCount(wordCount - 1);
    }
  };

  const handleLogout = async () => {
    if (await logout()) {
      console.log("Logout başarılı");
      navigate("/login");
    } else {
      console.log("Logout başarısız");
    }
  };

  const handleSubmit = async () => {
    if (await changeWordCount(uid, wordCount)) {
      console.log("yeni kelime sayısı güncelleştirildi.");
      toast.success("Kelime sayısı değiştirildi.");
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
    console.log("Submit button clicked");
  };

  return (
    <>
      <Toaster></Toaster>
      <div className="container-fluid  ">
        <Link to={"/"} className="text-decoration-none">
          <h1
            id="AppName"
            className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third "
          >
            VocabMentor
          </h1>
        </Link>
        <Link
          to={"/"}
          className="position-absolute mt-4 ms-4 btn bg-fourth primary"
        >
          {" "}
          <i class="fa-solid fa-chevron-left"></i>
        </Link>
        <div className="settings-container  ">
          <div className="h-75 d-flex flex-column mt-5 p-3 align-items-center justify-content-evenly">
            <h1 className="h1 text-center my-3">Kelime sayısını değiştir</h1>
            <div className="mx-auto">
              <button className="btn bg-third" onClick={increaseWordCount}>
                +
              </button>
              <span className="h3 mx-2">{wordCount}</span>
              <button className="btn bg-third" onClick={decreaseWordCount}>
                -
              </button>
            </div>
            <button className="btn bg-fourth primary" onClick={handleSubmit}>
              Onayla
            </button>{" "}
          </div>
        </div>
        <button
          className="btn btn-danger mx-auto d-block"
          onClick={handleLogout}
        >
          Çıkış yap
        </button>
      </div>
    </>
  );
};

export default Settings;
