import { initializeApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
} from "firebase/auth";
import {
  getFirestore,
  setDoc,
  getDoc,
  doc,
  addDoc,
  collection,
  getDocs,
  updateDoc,
} from "firebase/firestore";

import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { pass, sign } from "three/examples/jsm/nodes/Nodes.js";
import toast from "react-hot-toast";

const firebaseConfig = {
  apiKey: "AIzaSyAj1Ro6Fz2mtZvJlkdE6fHs3L-r38JeiBU",
  authDomain: "vocabmentor-5442c.firebaseapp.com",
  projectId: "vocabmentor-5442c",
  storageBucket: "vocabmentor-5442c.appspot.com",
  messagingSenderId: "726811599707",
  appId: "1:726811599707:web:7979ab51c0a435b607b07e",
  measurementId: "G-5X0RH2TEZR",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
export { db, setDoc, doc };
export const register = async (name, email, password) => {
  try {
    const { user } = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );
    const capitilize = (str) => {
      return str.charAt(0).toUpperCase() + str.slice(1);
    };

    await addUserInfoToFirestore(user.uid, capitilize(name), email);
    return user;
  } catch (error) {
    toast.error(error.message);
  }
};

export const login = async (email, password) => {
  try {
    const { user } = await signInWithEmailAndPassword(auth, email, password);
    return user;
  } catch (error) {
    if (error.code === "auth/invalid-credential") {
      toast.error("Parola veya mail bilgisi yanlış.");
    } else {
      console.error("Beklenmeyen bir hata oluştu:", error);
      toast.error("Bilinmeyen bir hata oluştu.");
    }
    throw error;
  }
};
export const logout = async () => {
  try {
    await signOut(auth);
    return true;
  } catch (error) {
    toast.error(error.message);
  }
};

export const resetpassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
    toast.success("Yenileme linki  gönderildi.");
    return true;
  } catch (error) {
    toast.error(error.message);
  }
};

const addUserInfoToFirestore = async (userId, name, email) => {
  try {
    await setDoc(doc(db, "users", userId), {
      name: name,
      email: email,
      statistics: {
        picture: {
          successRate: 0,
          totalAsked: 0,
        },
        word: {
          successRate: 0,
          totalAsked: 0,
        },
        sentence: {
          successRate: 0,
          totalAsked: 0,
        },
        voice: {
          successRate: 0,
          totalAsked: 0,
        },
      },
    });
    console.log("Kullanıcı bilgileri Firestore'a kaydedildi.");
  } catch (error) {
    console.error("Firestore'a kullanıcı bilgileri kaydedilirken hata:", error);
  }
};
export const uploadImageToStorage = async (imageFile) => {
  console.log(imageFile);
  const storageRef = ref(storage, "images/" + imageFile.name);
  await uploadBytes(storageRef, imageFile);
  const imageURL = await getDownloadURL(storageRef);
  return imageURL;
};

export const uploadAudioToStorage = async (audioFile) => {
  if (!audioFile) {
    return null;
  }
  const storage = getStorage();
  const storageRef = ref(storage, "audios/" + audioFile.name);
  await uploadBytes(storageRef, audioFile);
  const audioURL = await getDownloadURL(storageRef);
  return audioURL;
};

export const addWordToFirestore = async (
  uid,
  englishWord,
  turkishEquivalent,
  exampleSentences,
  imageFile,
  audioFile
) => {
  try {
    const imageURL = await uploadImageToStorage(imageFile);
    const audioURL = await uploadAudioToStorage(audioFile);
    const userWordsCollectionRef = collection(doc(db, "users", uid), "words");
    const newWord = {
      inEnglish: englishWord,
      inTurkish: turkishEquivalent,
      exampleSentences: exampleSentences,
      knowledgeCount: 0,
      lastKnownDate: "",
      pictureURL: imageURL,
      voiceURL: audioURL,
    };

    await addDoc(userWordsCollectionRef, newWord);
    console.log("Yeni kelime Firestore'a başarıyla eklendi.");
  } catch (error) {
    console.error("Firestore'a kelime eklenirken hata oluştu:", error);
    throw error;
  }
};

export const fetchUserName = async (uid) => {
  try {
    const userDoc = await getDoc(doc(db, "users", uid));
    if (userDoc.exists()) {
      const userData = userDoc.data();
      console.log(auth);
      return userData.name;
    } else {
      throw new Error("Kullanıcı bulunamadı");
    }
  } catch (error) {
    console.error("Firestore'dan kullanıcı ismi alınırken hata oluştu:", error);
    throw error;
  }
};
const getWordsFromFirestore = async (uid) => {
  try {
    const wordCollectionRef = collection(doc(db, "users", uid), "words");
    console.log("asd");
    const snapshot = await getDocs(wordCollectionRef);
    console.log("asdsadss", snapshot);
    const wordList = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    return wordList;
  } catch (error) {
    console.error("Firestore'dan kelimeleri alırken hata oluştu:", error);
  }
};
export const updateKnowledgeCountAndDate = async (
  uid,
  wordId,
  newLastKnownDate,
  newKnowledgeCount
) => {
  try {
    const wordRef = doc(db, "users", uid, "words", wordId);
    await updateDoc(wordRef, {
      lastKnownDate: newLastKnownDate,
      knowledgeCount: newKnowledgeCount,
    });
    console.log("Kelime özellikleri başarıyla güncellendi.");
  } catch (error) {
    console.error("Hata oluştu:", error);
  }
};

export const resetKnowledgeCount = async (uid, wordId) => {
  try {
    const wordRef = doc(db, "users", uid, "words", wordId);
    await updateDoc(wordRef, {
      knowledgeCount: 0,
    });
    console.log("Kelime özellikleri başarıyla güncellendi.");
    return true;
  } catch (error) {
    console.error("Hata oluştu:", error);
    return false;
  }
};
export const fetchWords = async (uid) => {
  try {
    const words = await getWordsFromFirestore(uid);
    console.log("Firestore'dan alınan kelimeler:", words);
    const regulatedWords = words.map((word) => {
      let question;
      let answer;
      let questionType;
      let englishWord;
      let id = word.id;
      let knowledgeCount = word.knowledgeCount;
      if (word.knowledgeCount === 0) {
        question = word.inEnglish;
        answer = word.inTurkish;
        questionType = "word";
        return { question, answer, questionType, id, knowledgeCount };
      } else if (word.knowledgeCount === 1) {
        const oneDayInMilliseconds = 24 * 60 * 60 * 1000;
        const lastKnownDate = new Date(word.lastKnownDate);
        const currentDate = new Date();
        if ((currentDate - lastKnownDate) / oneDayInMilliseconds >= 1) {
          question = word.inTurkish;
          answer = word.inEnglish;
          questionType = "word";
          return { question, answer, questionType, id, knowledgeCount };
        } else {
          return null;
        }
      } else if (word.knowledgeCount === 2) {
        const oneWeekInMilliseconds = 7 * 24 * 60 * 60 * 1000;
        const lastKnownDate = new Date(word.lastKnownDate);
        const currentDate = new Date();
        if ((currentDate - lastKnownDate) / oneWeekInMilliseconds >= 1) {
          question = word.exampleSentences[0];
          answer = word.inTurkish;
          englishWord = word.inEnglish;
          questionType = "sentence";
          return {
            question,
            answer,
            englishWord,
            questionType,
            id,
            knowledgeCount,
          };
        } else {
          return null;
        }
      } else if (word.knowledgeCount === 3) {
        const oneMonthInMilliseconds = 30 * 24 * 60 * 60 * 1000;
        const lastKnownDate = new Date(word.lastKnownDate);
        const currentDate = new Date();
        if ((currentDate - lastKnownDate) / oneMonthInMilliseconds >= 1) {
          question = word.exampleSentences[1];
          answer = word.inTurkish;
          englishWord = word.inEnglish;
          questionType = "sentence";
          return {
            question,
            answer,
            englishWord,
            questionType,
            id,
            knowledgeCount,
          };
        } else {
          return null;
        }
      } else if (word.knowledgeCount === 4) {
        const threeMonthsInMilliseconds = 3 * 30 * 24 * 60 * 60 * 1000; //
        const lastKnownDate = new Date(word.lastKnownDate);
        const currentDate = new Date();
        if ((currentDate - lastKnownDate) / threeMonthsInMilliseconds >= 1) {
          question = word.exampleSentences[2];
          answer = word.inTurkish;
          englishWord = word.inEnglish;
          questionType = "sentence";
          return {
            question,
            answer,
            englishWord,
            questionType,
            id,
            knowledgeCount,
          };
        } else {
          return null;
        }
      } else if (word.knowledgeCount === 5) {
        const sixMonthsInMilliseconds = 6 * 30 * 24 * 60 * 60 * 1000;
        const lastKnownDate = new Date(word.lastKnownDate);
        const currentDate = new Date();
        console.log(currentDate.toISOString());
        if ((currentDate - lastKnownDate) / sixMonthsInMilliseconds >= 1) {
          question = word.pictureURL;
          answer = word.inTurkish;
          questionType = "picture";
          return { question, answer, questionType, id, knowledgeCount };
        } else {
          return null;
        }
      } else if (word.knowledgeCount === 6) {
        const oneYearInMilliseconds = 365 * 24 * 60 * 60 * 1000;
        const lastKnownDate = new Date(word.lastKnownDate);
        const currentDate = new Date();
        if ((currentDate - lastKnownDate) / oneYearInMilliseconds >= 1) {
          question = word.voiceURL;
          answer = word.inEnglish;
          questionType = "voice";
          return { question, answer, questionType, id, knowledgeCount };
        } else {
          return null;
        }
      } else {
        return null;
      }
    });

    const filteredWords = regulatedWords.filter((word) => word !== null);

    console.log("regulated words", filteredWords);
    return filteredWords;
  } catch (error) {
    console.error("Firestore'dan kelimeleri alırken hata oluştu:", error);
  }
};
export const changeWordCount = async (uid, newWordCount) => {
  try {
    if (uid) {
      const userRef = doc(db, "users", uid);
      const userDoc = await getDoc(userRef);
      await updateDoc(userRef, {
        settings: {
          wordCount: newWordCount,
        },
      });
      console.log("başarılı");
      return true;
    }
  } catch (error) {
    console.log("hata meydana geldi", error);
  }
};

export const getQuestionCount = async (uid) => {
  try {
    if (uid) {
      const userRef = doc(db, "users", uid);
      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        const userData = userDoc.data();
        console.log();
        const wordCount = userData.settings;
        console.log(wordCount);
        return wordCount;
      } else {
        console.error("Kullanıcı belgesi bulunamadı.");
        return null;
      }
    }
  } catch (error) {
    console.error("Kullanıcı belgesi alınırken hata oluştu:", error);
  }
};
export const updateStatistics = async (uid, questionType, successPoint) => {
  try {
    if (uid) {
      const userRef = doc(db, "users", uid);
      const userDoc = await getDoc(userRef);
      const userStatistics = userDoc.data().statistics;

      let questionMap;
      switch (questionType) {
        case "word":
          questionMap = userStatistics.word;
          break;
        case "sentence":
          questionMap = userStatistics.sentence;
          break;
        case "picture":
          questionMap = userStatistics.picture;
          break;
        case "voice":
          questionMap = userStatistics.voice;
          break;
        default:
          console.error("Geçersiz soru türü:", questionType);
          return;
      }
      const updatedQuestionMap = {
        ...questionMap,
        successRate: questionMap.successRate + successPoint,
        totalAsked: questionMap.totalAsked + 1,
      };

      await updateDoc(userRef, {
        statistics: {
          ...userStatistics,
          [questionType]: updatedQuestionMap,
        },
      });

      console.log(`${questionType} için istatistikler güncellendi`);
    }
  } catch (error) {
    console.error("İstatistikler güncellenirken hata oluştu:", error);
  }
};
export const getStatistics = async (uid) => {
  try {
    if (uid) {
      const userRef = doc(db, "users", uid);
      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const userStatistics = userData.statistics;
        console.log("Kullanıcı istatistikleri:", userStatistics);
        return userStatistics;
      } else {
        console.error("Kullanıcı belgesi bulunamadı.");
        return null;
      }
    } else {
      console.error("Geçersiz kullanıcı ID'si.");
      return null;
    }
  } catch (error) {
    console.error("Kullanıcı istatistikleri alınırken hata oluştu:", error);
    return null;
  }
};
export { app, auth };
