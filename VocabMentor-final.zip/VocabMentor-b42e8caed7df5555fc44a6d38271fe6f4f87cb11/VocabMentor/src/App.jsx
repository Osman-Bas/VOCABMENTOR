import { useState } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginScreen from "./Components/LoginScreen";
import RegisterScreen from "./Components/RegisterScreen";
import WordAddForm from "./Components/WordAddForm";
import { Toaster } from "react-hot-toast";
import ResetPassword from "./Components/ResetPassword";
import Dashboard from "./Components/Dashboard";
import Quiz from "./Components/Quiz";
import Settings from "./Components/Settings";
import Analysis from "./Components/Analysis";
function App() {
  const [count, setCount] = useState(0);

  return (
    <Router>
      <div className="App">
        <Toaster></Toaster>
        <Routes>
          <Route path="/" element={<Dashboard />}></Route>
          <Route exact path="/login" element={<LoginScreen />} />
          <Route path="/register" element={<RegisterScreen />} />
          <Route path="/wordaddpage" element={<WordAddForm />}></Route>
          <Route path="/resetpassword" element={<ResetPassword />}></Route>
          <Route path="/settings" element={<Settings />}></Route>
          <Route path="/quiz" element={<Quiz />}></Route>
          <Route path="/analysis" element={<Analysis />}></Route>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
