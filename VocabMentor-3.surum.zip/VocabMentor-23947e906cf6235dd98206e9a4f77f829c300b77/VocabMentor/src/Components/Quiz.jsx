import React, { useState, useEffect } from "react";
import { fetchWords } from "../firebase";
import { Link } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import loadingGif from "../assets/Spin@1x-1.0s-200px-200px (1).gif";

const Quiz = () => {
  const [words, setWords] = useState([]);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [englishWord, setEnglishWord] = useState("");
  const [isAnswerCorrect, setIsAnswerCorrect] = useState(null);
  const [showNextButton, setShowNextButton] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const fetchedWords = await fetchWords();
        setWords(fetchedWords);
        setLoading(false);
      } catch (error) {
        console.error("Firestore'dan kelimeleri alırken hata oluştu:", error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleCheckAnswer = () => {
    const correctTurkishEquivalent = words[currentWordIndex].inTurkish;
    if (
      englishWord.trim().toLowerCase() ===
      correctTurkishEquivalent.toLowerCase()
    ) {
      setIsAnswerCorrect(true);
      setIsChecked(true);
      toast.success("Doğru cevap!");
    } else {
      setIsAnswerCorrect(false);
      setIsChecked(true);
      // Yanlış cevap olduğunda toast mesajı içerisinde doğru cevabı da göster
      toast.error(`Yanlış cevap. Doğru cevap: ${correctTurkishEquivalent}`);
    }
    setShowNextButton(true);
  };

  const handleNextWord = () => {
    setCurrentWordIndex((prevIndex) => (prevIndex + 1) % words.length);
    setEnglishWord("");
    setIsAnswerCorrect(null);
    setShowNextButton(false);
    setIsChecked(false);
  };

  return (
    <>
      <Toaster />
      <div className="container-fluid">
        <div>
          <Link to={"/"} className="text-decoration-none">
            <h1
              id="AppName"
              className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third"
            >
              VocabMentor
            </h1>
          </Link>
          <div className="position-relative">
            {loading ? (
              <div className="loading">
                {" "}
                <img
                  className="loading-gif"
                  src={loadingGif}
                  alt="Yükleniyor..."
                />
              </div>
            ) : (
              words.length > 0 && (
                <div className="container quiz-container p-3 mt-3  d-flex justify-content-evenly align-items-center flex-column">
                  <p className="questionP">
                    {words[currentWordIndex].inEnglish}
                  </p>
                  <input
                    type="text"
                    className="form-control bg-primary border-0 quiz-input"
                    value={englishWord}
                    onChange={(e) => setEnglishWord(e.target.value)}
                  />
                  <button
                    className="btn bg-third mt-3"
                    onClick={handleCheckAnswer}
                    disabled={isChecked}
                  >
                    Kontrol et
                  </button>

                  {showNextButton && (
                    <button
                      className="btn bg-third mt-3"
                      onClick={handleNextWord}
                    >
                      Sonraki Soruya Geç
                    </button>
                  )}
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Quiz;
