import React, { useState, useEffect } from "react";
import {
  fetchWords,
  updateKnowledgeCountAndDate,
  resetKnowledgeCount,
  getQuestionCount,
  updateStatistics,
} from "../firebase";
import { Link, useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import loadingGif from "../assets/Spin@1x-1.0s-200px-200px (1).gif";

const Quiz = () => {
  const [words, setWords] = useState([]);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [isAnswerCorrect, setIsAnswerCorrect] = useState(null);
  const [showNextButton, setShowNextButton] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [questionCount, setQuestionCount] = useState(0);
  const [finish, setFinish] = useState(false);
  const [currentQuestionCount, setCurrentQuestionCount] = useState(2);
  const uid = localStorage.getItem("uid");
  const navigate = useNavigate();
  const markEnglishWord = (question, englishWord) => {
    const regex = new RegExp(englishWord, "gi");
    return question.replace(regex, (match) => `<u>${match}</u>`);
  };

  const fetchQuestionCount = async (fetchedWords) => {
    try {
      const count = await getQuestionCount(uid);
      console.log(fetchedWords.length);
      if (fetchedWords.length < count) {
        console.log("ife girdi");
        setCurrentQuestionCount(fetchedWords.length);
      } else {
        setCurrentQuestionCount(count);
      }
    } catch (error) {
      console.error("Soru sayısını alırken bir hata oluştu:", error);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (uid) {
          const fetchedWords = await fetchWords(uid);
          console.log("feçıt vörds", fetchedWords);
          console.log(fetchedWords.length);
          setWords(fetchedWords);
          setLoading(false);
          fetchQuestionCount(fetchedWords);
        } else {
          navigate("/login");
        }
      } catch (error) {
        console.error("Firestore'dan kelimeleri alırken hata oluştu:", error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (questionCount === currentQuestionCount) {
      setFinish(true);
    }
  }, [questionCount, currentQuestionCount]);

  const handleCheckAnswer = async () => {
    const correctAnswer = words[currentWordIndex].answer;
    const userEnteredAnswer = userAnswer.trim().toLowerCase();

    if (userEnteredAnswer === correctAnswer.toLowerCase()) {
      const successPoint = 1;
      setIsAnswerCorrect(true);
      toast.success("Doğru cevap!");
      try {
        const currentDate = new Date();
        const formattedDate = currentDate.toISOString();
        await updateKnowledgeCountAndDate(
          uid,
          words[currentWordIndex].id,
          formattedDate,
          words[currentWordIndex].knowledgeCount + 1
        );
        await updateStatistics(
          uid,
          words[currentWordIndex].questionType,
          successPoint
        );
        const updatedWords = words.map((word, index) => {
          if (index === currentWordIndex) {
            return {
              ...word,
              knowledgeCount: word.knowledgeCount + 1,
              lastKnownDate: formattedDate,
            };
          } else {
            return word;
          }
        });
        setWords(updatedWords);
      } catch (error) {
        console.error("Bilgileri güncellerken hata oluştu:", error);
        toast.error("Bilgileri güncellerken hata oluştu!");
      }
    } else {
      setIsAnswerCorrect(false);
      resetKnowledgeCount(uid, words[currentWordIndex].id);
      const successPoint = 0;
      await updateStatistics(
        uid,
        words[currentWordIndex].questionType,
        successPoint
      );
      toast.error(`Yanlış cevap. Doğru cevap: ${correctAnswer}`);
    }

    setIsChecked(true);
    setShowNextButton(true);
  };

  const handleNextWord = () => {
    setQuestionCount((prevCount) => prevCount + 1);
    setCurrentWordIndex((prevIndex) => (prevIndex + 1) % words.length);
    setUserAnswer("");
    setIsAnswerCorrect(null);
    setShowNextButton(false);
    setIsChecked(false);
  };

  const renderQuestion = () => {
    if (words.length === 0) {
      return (
        <>
          <p className="fs-3 text-center">
            Henüz kelime eklenmemiş veya sorulacak kelimeniz kalmamış. Lütfen
            daha sonra tekrar deneyin.
          </p>
          <Link className="btn p-3 bg-third " to={"/"}>
            Ana sayfaya dön{" "}
          </Link>
        </>
      );
    }

    const currentWord = words[currentWordIndex];
    switch (currentWord.questionType) {
      case "word":
        return (
          <>
            {" "}
            <p className="fs-3 text-center">Kelimenin karşılığını yazınız.</p>
            <p className="questionP">{currentWord.question}</p>
            <input
              type="text"
              className="form-control bg-primary border-0 quiz-input"
              value={userAnswer}
              placeholder="Cevabınızı girin:"
              onChange={(e) => setUserAnswer(e.target.value)}
              disabled={isChecked}
            />
            <button
              className="btn bg-third mt-3"
              onClick={handleCheckAnswer}
              disabled={isChecked}
            >
              Kontrol et
            </button>
          </>
        );
      case "sentence":
        return (
          <>
            {" "}
            <p className="fs-3 text-center">
              Altı çizili kelimenin türkçesini yazınız.
            </p>
            <p
              className="questionP"
              dangerouslySetInnerHTML={{
                __html: markEnglishWord(
                  currentWord.question,
                  currentWord.englishWord
                ),
              }}
            ></p>
            <input
              type="text"
              className="form-control bg-primary border-0 quiz-input"
              value={userAnswer}
              placeholder="Cevabınızı girin:"
              onChange={(e) => setUserAnswer(e.target.value)}
              disabled={isChecked}
            />
            <button
              className="btn bg-third mt-3"
              onClick={handleCheckAnswer}
              disabled={isChecked}
            >
              Kontrol et
            </button>
          </>
        );
      case "picture":
        return (
          <>
            <p className="fs-3 text-center ">
              Resimdeki kelimenin türkçesini yazınız.
            </p>
            <img
              src={currentWord.question}
              alt="Resim"
              className="questionImage my-5 rounded"
            />
            <input
              type="text"
              className="form-control bg-primary border-0 quiz-input"
              value={userAnswer}
              placeholder="Cevabınızı girin:"
              onChange={(e) => setUserAnswer(e.target.value)}
              disabled={isChecked}
            />
            <button
              className="btn bg-third mt-3"
              onClick={handleCheckAnswer}
              disabled={isChecked}
            >
              Kontrol et
            </button>
          </>
        );
      case "voice":
        return (
          <>
            {" "}
            <p className="fs-3 text-center ">
              Ses dosyasındaki kelimenin ingilizcesini yazınız.
            </p>
            <audio controls>
              <source src={currentWord.question} type="audio/mpeg" />
              Tarayıcınız ses öğesini desteklemiyor.
            </audio>
            <input
              type="text"
              className="form-control bg-primary border-0 quiz-input"
              value={userAnswer}
              placeholder="Cevabınızı girin:"
              onChange={(e) => setUserAnswer(e.target.value)}
              disabled={isChecked}
            />
            <button
              className="btn bg-third mt-3"
              onClick={handleCheckAnswer}
              disabled={isChecked}
            >
              Kontrol et
            </button>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <Toaster />
      <div className="container-fluid">
        <h1
          id="AppName"
          className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third "
        >
          VocabMentor
        </h1>
        <div>
          <div className="position-relative">
            {finish ? (
              <div className="container-fluid finish-container p-4 px-0 mt-3 d-flex justify-content-around align-items-center ">
                <img
                  className="party-emoji"
                  src="https://emojiisland.com/cdn/shop/products/4_large.png?v=1571606116"
                  alt=""
                />

                <div
                  className="d-flex flex-column align-items-center h-75
                justify-content-between"
                >
                  <h1 className="fs-1 text-center fourth">
                    Tebrikler! Hepsini bitirdin.
                  </h1>
                  <h2 className="fs-3 text-center fourth">
                    {currentQuestionCount} olan soru sayısını ayarlardan
                    değiştirebilirsin.
                  </h2>
                  <Link className="btn p-3 bg-third " to={"/"}>
                    Ana sayfaya dön{" "}
                  </Link>
                </div>

                <img
                  className="party-emoji"
                  src="https://images.emojiterra.com/google/noto-emoji/unicode-15.1/color/1024px/1f389.png"
                  alt=""
                />
              </div>
            ) : (
              <>
                {loading ? (
                  <div className="loading">
                    <img
                      className="loading-gif"
                      src={loadingGif}
                      alt="Yükleniyor..."
                    />
                  </div>
                ) : (
                  <div className="container quiz-container p-4 px-0 mt-3 d-flex justify-content-evenly align-items-center flex-column">
                    {renderQuestion()}

                    {showNextButton && (
                      <button
                        className="btn bg-third mt-3"
                        onClick={handleNextWord}
                      >
                        Sonraki Soruya Geç
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Quiz;
