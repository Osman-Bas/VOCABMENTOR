import React, { useState, useEffect } from "react";
import { getStatistics } from "../firebase";
import { Link, useNavigate } from "react-router-dom";
import { PieChart } from "@mui/x-charts/PieChart";
const Analysis = () => {
  const [statistics, setStatistics] = useState(null);
  const uid = localStorage.getItem("uid");
  const palette = ["#dbe2ef", "#112d4e"];
  useEffect(() => {
    const fetchUserStatistics = async () => {
      const userStatistics = await getStatistics(uid);
      setStatistics(userStatistics);
    };

    fetchUserStatistics();
  }, [uid]);
  const handlePrint = () => {
    window.print();
  };
  if (!statistics) {
    return <div>Loading...</div>;
  }
  return (
    <>
      <div className="container-fluid">
        <Link to={"/"} className="text-decoration-none">
          <h1
            id="AppName"
            className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third "
          >
            VocabMentor
          </h1>
        </Link>
        <div className="analysis-container d-flex flex-column justify-content-between grid gap-3">
          <div className="row d-flex justify-content-between  mt-4 ">
            <div className="col-3">
              <span className="ms-1 fs-1 fw-bold">Analiz Raporu</span>
            </div>
            <div className="col-3">
              {" "}
              <button
                onClick={handlePrint}
                className="btn bg-fourth primary float-end me-2"
              >
                {" "}
                <i className="fa-solid fa-print me-1"></i>
                Yazdır
              </button>
            </div>
          </div>
          <div className="row d-flex">
            <div className="col-6">
              <div className="analysis-card  ">
                <div className="analysis-card-header">
                  <span className="fw-bold fs-4">Kelime Bilme Başarısı</span>
                </div>
                <div className="analysis-card-body d-flex ">
                  <span className="fs-1 align-self-center ms-1">
                    {statistics.word.successRate}/{statistics.word.totalAsked}
                  </span>
                  <PieChart
                    colors={palette}
                    series={[
                      {
                        data: [
                          {
                            id: 0,
                            value: statistics.word.successRate,
                            label: "Doğru Sayısı",
                          },
                          {
                            id: 1,
                            value:
                              statistics.word.totalAsked -
                              statistics.word.successRate,
                            label: "Yanlış Sayısı ",
                          },
                        ],
                        innerRadius: 15,
                        outerRadius: 50,
                        paddingAngle: 5,
                        cornerRadius: 5,
                        startAngle: -180,
                        endAngle: 180,
                        cx: 1,
                        cy: 70,
                      },
                    ]}
                    width={300}
                    height={150}
                  />
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="analysis-card">
                <div className="analysis-card-header">
                  <span className="fw-bold fs-4">Cümle Bilme Başarısı</span>
                </div>
                <div className="analysis-card-body d-flex ">
                  <span className="fs-1 align-self-center ms-1">
                    {statistics.sentence.successRate}/
                    {statistics.sentence.totalAsked}
                  </span>
                  <PieChart
                    colors={palette}
                    series={[
                      {
                        data: [
                          {
                            id: 0,
                            value: statistics.sentence.successRate,
                            label: "Doğru Sayısı",
                          },
                          {
                            id: 1,
                            value:
                              statistics.sentence.totalAsked -
                              statistics.sentence.successRate,
                            label: "Yanlış Sayısı ",
                          },
                        ],
                        innerRadius: 15,
                        outerRadius: 50,
                        paddingAngle: 5,
                        cornerRadius: 5,
                        startAngle: -180,
                        endAngle: 180,
                        cx: 1,
                        cy: 70,
                      },
                    ]}
                    width={300}
                    height={150}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="row d-flex">
            <div className="col-6">
              <div className="analysis-card  ">
                <div className="analysis-card-header">
                  <span className="fw-bold fs-4">Resim Bilme Başarısı</span>
                </div>
                <div className="analysis-card-body d-flex ">
                  <span className="fs-1 align-self-center ms-1">
                    {statistics.picture.successRate}/
                    {statistics.picture.totalAsked}
                  </span>
                  <PieChart
                    colors={palette}
                    series={[
                      {
                        data: [
                          {
                            id: 0,
                            value: statistics.picture.successRate,
                            label: "Doğru Sayısı",
                          },
                          {
                            id: 1,
                            value:
                              statistics.picture.totalAsked -
                              statistics.picture.successRate,
                            label: "Yanlış Sayısı ",
                          },
                        ],
                        innerRadius: 15,
                        outerRadius: 50,
                        paddingAngle: 5,
                        cornerRadius: 5,
                        startAngle: -180,
                        endAngle: 180,
                        cx: 1,
                        cy: 70,
                      },
                    ]}
                    width={300}
                    height={150}
                  />
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="analysis-card">
                <div className="analysis-card-header">
                  <span className="fw-bold fs-4">Ses Bilme Başarısı</span>
                </div>
                <div className="analysis-card-body d-flex ">
                  <span className="fs-1 align-self-center ms-1">
                    {statistics.voice.successRate}/{statistics.voice.totalAsked}
                  </span>
                  <PieChart
                    colors={palette}
                    series={[
                      {
                        data: [
                          {
                            id: 0,
                            value: statistics.voice.successRate,
                            label: "Doğru Sayısı",
                          },
                          {
                            id: 1,
                            value:
                              statistics.voice.totalAsked -
                              statistics.voice.successRate,
                            label: "Yanlış Sayısı ",
                          },
                        ],
                        innerRadius: 15,
                        outerRadius: 50,
                        paddingAngle: 5,
                        cornerRadius: 5,
                        startAngle: -180,
                        endAngle: 180,
                        cx: 1,
                        cy: 70,
                      },
                    ]}
                    width={300}
                    height={150}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Analysis;
