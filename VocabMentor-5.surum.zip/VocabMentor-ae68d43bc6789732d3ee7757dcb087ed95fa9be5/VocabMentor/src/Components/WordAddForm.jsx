import React, { useState } from "react";
import { Link } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import loadingGif from "../assets/Spin@1x-1.0s-200px-200px (1).gif";
import { addWordToFirestore, uploadAudioToStorage } from "../firebase";

const WordAddForm = () => {
  const [englishWord, setEnglishWord] = useState("");
  const [turkishEquivalent, setTurkishEquivalent] = useState("");
  const [exampleSentences, setExampleSentences] = useState(["", "", ""]);
  const [pictureFile, setPictureFile] = useState(null);
  const [audioFile, setAudioFile] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [imagePreview, setImagePreview] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    if (
      !englishWord ||
      !turkishEquivalent ||
      exampleSentences.some((sentence) => !sentence.trim())
    ) {
      setErrorMessage(
        "İngilizce kelime, Türkçe karşılığı ve en az üç örnek cümle girmelisiniz."
      );
      setLoading(false);
      return;
    }

    try {
      const audioURL = await uploadAudioToStorage(audioFile);
      await addWordToFirestore(
        englishWord,
        turkishEquivalent,
        exampleSentences.filter((sentence) => sentence.trim()),
        pictureFile,
        audioFile ? audioFile : null
      );
      toast.success("Kelime Firebase'a başarıyla eklendi.");
      console.log("Kelime Firebase'a başarıyla eklendi.");
      setEnglishWord("");
      setTurkishEquivalent("");
      setExampleSentences(["", "", ""]);
      setPictureFile(null);
      setAudioFile(null);
      setErrorMessage("");
      setImagePreview(null);
    } catch (error) {
      console.error("Firebase'a kelime eklenirken hata oluştu:", error);
      setErrorMessage(
        "Kelime eklenirken bir hata oluştu. Lütfen tekrar deneyin."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleImageSelect = (e) => {
    const file = e.target.files[0];
    setPictureFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result);
    };
    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleAudioSelect = (e) => {
    const file = e.target.files[0];
    setAudioFile(file);
  };

  const handleExampleSentenceChange = (e, index) => {
    const newSentences = [...exampleSentences];
    newSentences[index] = e.target.value;
    setExampleSentences(newSentences);
  };

  const addNewExampleSentence = () => {
    if (exampleSentences.length < 7) {
      setExampleSentences([...exampleSentences, ""]);
    }
  };

  const removeExampleSentence = (index) => {
    // Örnek cümle sayısı 3'ten fazla ise cümleyi kaldır
    if (exampleSentences.length > 3) {
      const newSentences = [...exampleSentences];
      newSentences.splice(index, 1);
      setExampleSentences(newSentences);
    }
  };

  return (
    <>
      <Toaster />
      <div className="container-fluid">
        <div>
          <Link to={"/dashboard"} className="text-decoration-none">
            <h1
              id="AppName"
              className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third "
            >
              VocabMentor
            </h1>
          </Link>
          {loading ? (
            <div className="loading d-flex align-items-center justify-content-center">
              <img
                className="loading-gif"
                src={loadingGif}
                alt="Yükleniyor..."
              />
            </div>
          ) : (
            <div className="container word-add-container position-relative p-3 mt-3">
              <h1 className="p-3 text-center fourth">Kelime Ekle</h1>
              {errorMessage && (
                <div className="alert alert-danger text-center">
                  {errorMessage}
                </div>
              )}

              <div className="row">
                <div className="col-md-6">
                  <form>
                    <div className="row mb-3">
                      <div className="col">
                        <label className="form-label fourth">
                          İngilizce Kelime:
                        </label>
                        <input
                          type="text"
                          className="form-control bg-primary border-0"
                          value={englishWord}
                          onChange={(e) => setEnglishWord(e.target.value)}
                        />
                      </div>
                      <div className="col">
                        <label className="form-label fourth">
                          Türkçe Karşılığı:
                        </label>
                        <input
                          type="text"
                          className="form-control bg-primary border-0"
                          value={turkishEquivalent}
                          onChange={(e) => setTurkishEquivalent(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="mb-3">
                      <label className="form-label fourth">
                        Örnek Cümleler: (En az 3 tane giriniz.)
                      </label>
                      {exampleSentences.map((sentence, index) => (
                        <div key={index} className="mb-2">
                          <div className="d-flex align-items-center">
                            <input
                              type="text"
                              className="form-control bg-primary border-0 me-2"
                              value={sentence}
                              onChange={(e) =>
                                handleExampleSentenceChange(e, index)
                              }
                            />
                            <button
                              type="button"
                              className="btn btn-danger btn-sm"
                              onClick={() => removeExampleSentence(index)}
                            >
                              Sil
                            </button>
                          </div>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn primary bg-fourth btn-sm mt-2"
                        onClick={addNewExampleSentence}
                        disabled={exampleSentences.length >= 7}
                      >
                        Yeni Örnek Cümle Ekle
                      </button>
                    </div>
                  </form>
                </div>
                <div className="col-md-6 d-flex flex-column  align-items-center">
                  <div className="w-100">
                    {imagePreview && (
                      <div className="text-center mt-3">
                        <img
                          src={imagePreview}
                          alt="Resim önizleme"
                          className="img-thumbnail"
                          style={{ maxWidth: "200px", maxHeight: "200px" }}
                        />
                      </div>
                    )}

                    <div className="mb-3 ">
                      <label className="form-label fourth">Resim:</label>
                      <input
                        type="file"
                        className="form-control bg-primary border-0"
                        accept="image/*"
                        onChange={handleImageSelect}
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label fourth">Sesli Okunuş:</label>
                      <input
                        type="file"
                        className="form-control bg-primary border-0"
                        accept="audio/*"
                        onChange={handleAudioSelect}
                      />
                    </div>
                  </div>
                  <button
                    className="btn bg-fourth primary text-center px-4 align-items-center justify-content-center d-flex mt-3"
                    type="submit"
                    onClick={handleSubmit}
                  >
                    Ekle
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default WordAddForm;
