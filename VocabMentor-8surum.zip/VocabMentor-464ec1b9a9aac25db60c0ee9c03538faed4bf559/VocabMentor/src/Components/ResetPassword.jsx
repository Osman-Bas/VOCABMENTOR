import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { resetpassword } from "../firebase";
import loadingGif from "../assets/Spin@1x-1.0s-200px-200px (1).gif";
const ResetPassword = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await resetpassword(email);
      console.log("başarılı");
    } catch (error) {
      console.error("Şifre sıfırlanırken hata oluştu:", error);
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="login-container container-fluid">
      <h1
        id="AppName"
        className="text-center align-items-center justify-content-center d-flex .jersey-10-regular third "
      >
        VocabMentor
      </h1>
      {loading ? (
        <div className="loading d-flex align-items-center justify-content-center">
          <img className="loading-gif" src={loadingGif} alt="Yükleniyor..." />
        </div>
      ) : (
        <div className="card login-card w-50 mx-auto third">
          <div className="login-card-body card-body ">
            <h2 className="text-center mb-4 primary">Şifreni yenile</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group mb-3">
                <input
                  type="email"
                  className="form-control bg-secondary border-0"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="E-posta"
                  required
                />
              </div>

              <div className="d-grid gap-2 mb-3">
                <button type="submit" className="btn bg-fourth primary">
                  Yenileme linki gönder.
                </button>
              </div>
              <div className="d-grid gap-2 mb-3">
                <Link
                  to="/login"
                  className="text-decoration-none  primary text-center"
                >
                  Giriş yap
                </Link>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResetPassword;
